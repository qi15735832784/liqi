#!/bin/bash
echo "helloworld"

if [ $? -eq 0 ]
then
    echo "PASS"
fi
